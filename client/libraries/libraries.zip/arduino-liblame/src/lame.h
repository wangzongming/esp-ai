/**
 * @file lame.h
 * @author Phil Schatzmann
 * @brief include lame from liblame
 * @version 0.1
 * @date 2021-08-07
 * 
 * @copyright Copyright (c) 2021
 * 
 */
#pragma once
#include "liblame/lame.h"
