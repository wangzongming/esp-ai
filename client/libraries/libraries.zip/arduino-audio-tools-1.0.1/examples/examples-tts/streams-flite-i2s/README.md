# Using FLITE Speach to Text

I am providing a simple sketch which generates sound data with the Flite text to speach engine.
You need to install https://github.com/pschatzmann/arduino-flite

In this demo we provide the result as I2SStream but you can easly replace with any other output stream. 

FLITE is quite big: you need to need to use the custom Partition Schema or RainMaker 4MB no OTA

## External DAC

for defails see the [Wiki](https://github.com/pschatzmann/arduino-audio-tools/wiki/External-DAC)