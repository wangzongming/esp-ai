#!/bin/bash
find . -name debug_custom.json -delete
find . -name debug.cfg -delete
find . -name esp32.svd -delete
