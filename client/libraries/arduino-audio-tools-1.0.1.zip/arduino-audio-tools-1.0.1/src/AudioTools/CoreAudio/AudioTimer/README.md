
Cross platform API for a repeating timer