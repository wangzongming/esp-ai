// legacy include 
#pragma once
#include "A2DPStream.h"
#warning AudioA2DP.h is obsolete: Use A2DPStream.h