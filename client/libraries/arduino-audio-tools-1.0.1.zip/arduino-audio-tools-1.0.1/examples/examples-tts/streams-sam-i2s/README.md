# Using SAM Speach to Text

I am providing a simple sketch which generates sound data with the SAM text to speach engine.
You need to install https://github.com/pschatzmann/arduino-SAM

In this demo we provide the result as I2SStream but you can easly replace with any other output stream. 

## External DAC

for defails see the [Wiki](https://github.com/pschatzmann/arduino-audio-tools/wiki/External-DAC)
