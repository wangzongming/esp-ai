var searchData=
[
  ['range_739',['range',['../classaudio__driver_1_1_pins_lyrat_mini_class.html#a037e8e370380046bec287bdc96942091',1,'audio_driver::PinsLyratMiniClass']]],
  ['rate_740',['rate',['../struct_i2_s_definition.html#a2ae50aca3292f8f72fa1afe1269bb8c4',1,'I2SDefinition']]],
  ['rate_5fcode_741',['rate_code',['../namespaceaudio__driver.html#a57ed9a91c0a184e4d8669f70d4cfb953',1,'audio_driver']]],
  ['rate_5fnum_742',['rate_num',['../namespaceaudio__driver.html#aee6eec1204925f0dfc2228bda0533d2f',1,'audio_driver']]],
  ['ref_743',['ref',['../struct_s_p_i_class.html#a1830ddb36c14bdd7057683e633f918c8',1,'SPIClass']]]
];
