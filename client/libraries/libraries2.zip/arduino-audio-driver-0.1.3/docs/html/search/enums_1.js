var searchData=
[
  ['channels_5ft_765',['channels_t',['../group__enumerations.html#gaac50a1392dd0aa905500c755148c556b',1,'DriverCommon.h']]],
  ['codec_5fmode_5ft_766',['codec_mode_t',['../group__enumerations.html#ga767db1c20919e0b4bcbf95cf741042f8',1,'DriverCommon.h']]]
];
