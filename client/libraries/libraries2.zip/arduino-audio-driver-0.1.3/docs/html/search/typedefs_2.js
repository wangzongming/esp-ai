var searchData=
[
  ['i2c_5fbus_5fhandle_5ft_762',['i2c_bus_handle_t',['../_driver_common_8h.html#a7031876dbed79a4a0cf1a5f82970275c',1,'DriverCommon.h']]]
];
