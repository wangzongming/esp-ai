var searchData=
[
  ['value_651',['value',['../classaudio__driver__local_1_1_optional.html#a464298ad7afeafebbb149f566ecabbab',1,'audio_driver_local::Optional']]],
  ['valueor_652',['valueOr',['../classaudio__driver__local_1_1_optional.html#ac79ae016f6483a4b7510d4f621c167c8',1,'audio_driver_local::Optional']]],
  ['vector_653',['Vector',['../classaudio__driver__local_1_1_vector.html#a4155c2064fb658b43b41b64756c6398f',1,'audio_driver_local::Vector::Vector(size_t len=20)'],['../classaudio__driver__local_1_1_vector.html#a3c671b50d8244040089ba15b0cb6592c',1,'audio_driver_local::Vector::Vector(int size, T value)'],['../classaudio__driver__local_1_1_vector.html#aeb52bff56db86416ddd8a9438d0336d7',1,'audio_driver_local::Vector::Vector(Vector&lt; T &gt; &amp;&amp;moveFrom)=default'],['../classaudio__driver__local_1_1_vector.html#a56c0272405a621eb8ef6725bad9a19a0',1,'audio_driver_local::Vector::Vector(Vector&lt; T &gt; &amp;copyFrom)'],['../classaudio__driver__local_1_1_vector.html#a11e874def9de9e45ce86f1d5ed73cc01',1,'audio_driver_local::Vector::Vector(T *from, T *to)']]]
];
