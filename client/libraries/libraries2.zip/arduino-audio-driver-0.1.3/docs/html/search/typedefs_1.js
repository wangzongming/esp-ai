var searchData=
[
  ['gpiopin_761',['GpioPin',['../_a_p_i___i2_c_8h.html#abdf74e3c0806040d87d21f1e1534c4a6',1,'GpioPin():&#160;API_I2C.h'],['../_a_p_i___s_p_i_8h.html#abdf74e3c0806040d87d21f1e1534c4a6',1,'GpioPin():&#160;API_SPI.h']]]
];
