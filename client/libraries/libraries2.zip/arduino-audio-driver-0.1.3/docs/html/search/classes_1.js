var searchData=
[
  ['codec_5fconfig_5ft_448',['codec_config_t',['../structcodec__config__t.html',1,'']]],
  ['codecconfig_449',['CodecConfig',['../classaudio__driver_1_1_codec_config.html',1,'audio_driver']]]
];
