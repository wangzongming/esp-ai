var searchData=
[
  ['tobits_649',['toBits',['../classaudio__driver_1_1_audio_driver_w_m8978_class.html#afaffd514793abc1a9dcdc3236bfd3f93',1,'audio_driver::AudioDriverWM8978Class']]],
  ['toi2s_650',['toI2S',['../classaudio__driver_1_1_audio_driver_w_m8978_class.html#a4abfad10bc5430ad0f4c067ff5a4be1d',1,'audio_driver::AudioDriverWM8978Class']]]
];
