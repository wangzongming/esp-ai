var searchData=
[
  ['output_5fdevice_720',['output_device',['../structcodec__config__t.html#a53991a860287c34f4e412af745d4bb66',1,'codec_config_t']]]
];
