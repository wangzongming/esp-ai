var searchData=
[
  ['mapvolume_579',['mapVolume',['../classaudio__driver_1_1_audio_driver.html#a5c9139f1cd859b1bcb2c6b16ea218c90',1,'audio_driver::AudioDriver']]],
  ['modemasterslave_580',['modeMasterSlave',['../classaudio__driver_1_1_audio_driver_w_m8960_class.html#a057bd9823253d287868d869ed21ca3ad',1,'audio_driver::AudioDriverWM8960Class']]]
];
