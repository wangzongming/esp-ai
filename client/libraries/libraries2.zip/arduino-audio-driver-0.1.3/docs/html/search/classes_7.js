var searchData=
[
  ['spiclass_467',['SPIClass',['../struct_s_p_i_class.html',1,'']]],
  ['spiconfig_468',['SPIConfig',['../struct_s_p_i_config.html',1,'']]]
];
