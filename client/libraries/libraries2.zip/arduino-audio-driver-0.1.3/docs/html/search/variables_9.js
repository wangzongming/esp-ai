var searchData=
[
  ['mclk_713',['mclk',['../structaudio__driver_1_1_pins_i2_s.html#ae4420d2deba4632c54badb549d9cfb37',1,'audio_driver::PinsI2S']]],
  ['miso_714',['miso',['../struct_s_p_i_config.html#a7918aeda38988c6d047b1abe185d6c20',1,'SPIConfig']]],
  ['mode_715',['mode',['../struct_i2_s_definition.html#a58b259b6331a0efa228683b513190b4d',1,'I2SDefinition']]],
  ['mosi_716',['mosi',['../struct_s_p_i_config.html#ae506f2c92d47737308ce15423fbfc049',1,'SPIConfig']]]
];
