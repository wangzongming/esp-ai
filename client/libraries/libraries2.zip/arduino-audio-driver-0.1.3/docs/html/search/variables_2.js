var searchData=
[
  ['cfg_681',['cfg',['../classaudio__driver_1_1_audio_driver_c_s42448_class.html#ad8d67cf9f0242d3b29e464ce9ae6d33f',1,'audio_driver::AudioDriverCS42448Class']]],
  ['channels_682',['channels',['../struct_i2_s_definition.html#ab5a0ee7843e4a3097806c3a4344944cd',1,'I2SDefinition']]],
  ['clk_683',['clk',['../struct_s_p_i_config.html#a880128a884b3a7f31cf7ff9a08e442bf',1,'SPIConfig']]],
  ['codec_5fcfg_684',['codec_cfg',['../classaudio__driver_1_1_audio_board.html#a4296f334f4441aae57fb5f43a0b77968',1,'audio_driver::AudioBoard::codec_cfg()'],['../classaudio__driver_1_1_audio_driver.html#a4296f334f4441aae57fb5f43a0b77968',1,'audio_driver::AudioDriver::codec_cfg()']]],
  ['cs_685',['cs',['../struct_s_p_i_config.html#a401cec32c23b8dfc8052bd73d7ae6b02',1,'SPIConfig']]],
  ['cs42448_686',['cs42448',['../classaudio__driver_1_1_audio_driver_c_s42448_class.html#a4a31e31df24961acffdaec543a25a79f',1,'audio_driver::AudioDriverCS42448Class']]]
];
