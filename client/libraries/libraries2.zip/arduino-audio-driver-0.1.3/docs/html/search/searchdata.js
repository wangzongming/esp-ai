var indexSectionsWithContent =
{
  0: "abcdefghiklmnoprstuvw~",
  1: "acdinopstv",
  2: "a",
  3: "acdelorv",
  4: "abcdeghilmoprstvw~",
  5: "abcdefgilmnoprstvw",
  6: "egis",
  7: "aceiops",
  8: "abcdhiklmoprsu",
  9: "adefhilort",
  10: "ap",
  11: "a"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "defines",
  10: "groups",
  11: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Macros",
  10: "Modules",
  11: "Pages"
};

