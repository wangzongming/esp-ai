var searchData=
[
  ['scl_744',['scl',['../struct_i2_c_config.html#a3e2bb798e2f223fbf471e1c2b634d803',1,'I2CConfig']]],
  ['sd_5factive_745',['sd_active',['../classaudio__driver_1_1_codec_config.html#ac585b3449d271276f8b679e8ab01b2ec',1,'audio_driver::CodecConfig::sd_active()'],['../classaudio__driver_1_1_driver_pins.html#ac585b3449d271276f8b679e8ab01b2ec',1,'audio_driver::DriverPins::sd_active()']]],
  ['sda_746',['sda',['../struct_i2_c_config.html#ae3eace66d9648e8cb1d9c5c7a03f56a0',1,'I2CConfig']]],
  ['set_5factive_747',['set_active',['../structaudio__driver_1_1_pins_s_p_i.html#afcc542ba9c5c0e2fbba65a0feab74508',1,'audio_driver::PinsSPI::set_active()'],['../structaudio__driver_1_1_pins_i2_c.html#afcc542ba9c5c0e2fbba65a0feab74508',1,'audio_driver::PinsI2C::set_active()']]],
  ['singal_5ftype_748',['singal_type',['../struct_i2_s_definition.html#a81cd10688e011094d3c0ccaee8a69bb7',1,'I2SDefinition']]],
  ['spi_749',['spi',['../classaudio__driver_1_1_driver_pins.html#a99492c2ad28a9f4670873619573c7faf',1,'audio_driver::DriverPins']]],
  ['spi_750',['SPI',['../_a_p_i___s_p_i_8h.html#a7ce95fd5dfb8f8c81e5a5e2cedd637be',1,'API_SPI.h']]]
];
