var searchData=
[
  ['bck_678',['bck',['../structaudio__driver_1_1_pins_i2_s.html#a8c7a8c2803dd2899881ecc66ac0c8366',1,'audio_driver::PinsI2S']]],
  ['bits_679',['bits',['../struct_i2_s_definition.html#adeb4d7cae3090eef02034eec5efcb122',1,'I2SDefinition']]],
  ['bufferlen_680',['bufferLen',['../classaudio__driver__local_1_1_vector.html#a52a25bb51473f2562b9d2b921d68ac52',1,'audio_driver_local::Vector']]]
];
