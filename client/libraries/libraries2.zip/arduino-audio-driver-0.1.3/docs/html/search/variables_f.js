var searchData=
[
  ['touch_5flimit_751',['touch_limit',['../classaudio__driver_1_1_driver_touch_class.html#ac6d53e051a63ad88fa43bd6e68c28930',1,'audio_driver::DriverTouchClass']]]
];
