var searchData=
[
  ['wordlength_654',['wordLength',['../classaudio__driver_1_1_audio_driver_w_m8960_class.html#a3ac8404aa88c0fbb927d1704059b94c2',1,'audio_driver::AudioDriverWM8960Class']]]
];
