var searchData=
[
  ['reset_615',['reset',['../classaudio__driver__local_1_1_optional.html#ad20897c5c8bd47f5d4005989bead0e55',1,'audio_driver_local::Optional']]],
  ['resize_616',['resize',['../classaudio__driver__local_1_1_vector.html#ab97207911c43773bf4ecd3d3a5a1f271',1,'audio_driver_local::Vector::resize(int newSize, T value)'],['../classaudio__driver__local_1_1_vector.html#a1609500c4d3ed333eef5a66b73a08102',1,'audio_driver_local::Vector::resize(int newSize)']]],
  ['resize_5finternal_617',['resize_internal',['../classaudio__driver__local_1_1_vector.html#a92a1834eff62d1b55c1f7011a99da544',1,'audio_driver_local::Vector']]]
];
