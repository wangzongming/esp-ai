var searchData=
[
  ['sample_5fbits_5ft_774',['sample_bits_t',['../group__enumerations.html#ga69c4b817c522e31496b9b6b6cda2926d',1,'DriverCommon.h']]],
  ['samplerate_5ft_775',['samplerate_t',['../group__enumerations.html#ga9455c9aa894b64d5d3997a038141991b',1,'DriverCommon.h']]],
  ['singal_5ft_776',['singal_t',['../group__enumerations.html#ga328fcdb825daa9aa04f1567a0498543b',1,'DriverCommon.h']]]
];
